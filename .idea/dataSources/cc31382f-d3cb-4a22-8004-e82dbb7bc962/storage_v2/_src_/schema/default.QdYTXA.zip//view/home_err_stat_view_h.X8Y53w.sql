CREATE VIEW default.home_err_stat_view_h
            (
             `appId` String,
             `errorType` String,
             `errorUrlCount` UInt64,
             `urlCount` UInt64,
             `total` UInt64,
             `statDate` String,
             `statHour` String
                )
AS
SELECT appId,
       errorType,
       uniqExact(errorUrl)         AS errorUrlCount,
       uniqExact(url)              AS urlCount,
       count(*)                    AS total,
       substring(errorTime, 1, 10) AS statDate,
       substring(errorTime, 12, 2) AS statHour
FROM default.flink_detail_err
GROUP BY appId,
         errorType,
         substring(errorTime, 1, 10),
         substring(errorTime, 12, 2);

