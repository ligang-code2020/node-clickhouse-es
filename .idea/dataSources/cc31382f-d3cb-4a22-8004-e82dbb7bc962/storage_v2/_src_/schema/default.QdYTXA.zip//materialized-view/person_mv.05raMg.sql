CREATE MATERIALIZED VIEW default.person_mv
            (
             `name` String,
             `cnt` UInt64,
             `statTime` UInt32
                )
            ENGINE = SummingMergeTree
                PARTITION BY statTime
                ORDER BY (statTime, name)
                SETTINGS index_granularity = 8192
AS
SELECT name,
       count(address)         AS cnt,
       toYYYYMMDD(insertTime) AS statTime
FROM default.person
GROUP BY name,
         toYYYYMMDD(insertTime);

