CREATE VIEW default.person_view
            (
             `name` String,
             `cnt` UInt64,
             `statTime` UInt32
                )
AS
SELECT name,
       count(address)         AS cnt,
       toYYYYMMDD(insertTime) AS statTime
FROM default.person
GROUP BY name,
         toYYYYMMDD(insertTime);

