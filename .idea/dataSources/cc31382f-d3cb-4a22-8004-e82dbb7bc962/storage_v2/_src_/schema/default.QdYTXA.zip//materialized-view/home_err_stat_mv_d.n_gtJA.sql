CREATE MATERIALIZED VIEW default.home_err_stat_mv_d
            (
             `appId` String,
             `errorType` String,
             `errorUrlCount` UInt64,
             `urlCount` UInt64,
             `total` UInt64,
             `partDate` String
                )
            ENGINE = SummingMergeTree
                PARTITION BY partDate
                ORDER BY (appId, errorType, partDate)
                SETTINGS index_granularity = 8192
AS
SELECT appId,
       errorType,
       uniqExact(errorUrl) AS errorUrlCount,
       uniqExact(url)      AS urlCount,
       count(*)            AS total,
       partDate
FROM default.flink_detail_err
GROUP BY appId,
         errorType,
         partDate;

